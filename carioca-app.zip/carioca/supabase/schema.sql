-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Cards: the single source of truth for the intelligence layer
CREATE TABLE cards (
  id TEXT NOT NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  PRIMARY KEY (id, user_id),

  portuguese TEXT NOT NULL,
  english TEXT,
  type TEXT CHECK (type IN ('giria','vocab','frase_pronta','grammar','sentence')),
  cluster TEXT,
  contrast TEXT,
  scenario TEXT,
  introduced_day INTEGER DEFAULT 1,
  source TEXT DEFAULT 'seed',

  -- Prerequisite graph: [{cardId, minMastery}]
  prerequisites JSONB DEFAULT '[]',

  -- SM-2 intelligence layer
  mastery INTEGER DEFAULT 0 CHECK (mastery BETWEEN 0 AND 5),
  ease_factor FLOAT DEFAULT 2.5,
  interval INTEGER DEFAULT 0,
  reps INTEGER DEFAULT 0,
  next_review TIMESTAMPTZ DEFAULT NOW(),

  -- Sentence mode tracking
  sentence_appearances INTEGER DEFAULT 0,
  sentence_avg_quality FLOAT DEFAULT 0,

  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- User-level state
CREATE TABLE user_state (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  fluency_rating INTEGER DEFAULT 1000,
  momentum INTEGER DEFAULT 75,
  total_sessions INTEGER DEFAULT 0,
  last_session_date DATE,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Every card interaction logged
CREATE TABLE card_reviews (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  card_id TEXT NOT NULL,
  quality INTEGER CHECK (quality BETWEEN 1 AND 5),
  mode TEXT CHECK (mode IN ('study','swipe','sentence','unlock_challenge')),
  session_id UUID,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Session summaries
CREATE TABLE sessions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  mode TEXT,
  cards_reviewed INTEGER DEFAULT 0,
  correct INTEGER DEFAULT 0,
  almost INTEGER DEFAULT 0,
  missed INTEGER DEFAULT 0,
  peak_combo INTEGER DEFAULT 0,
  fluency_delta INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Row Level Security
ALTER TABLE cards ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_state ENABLE ROW LEVEL SECURITY;
ALTER TABLE card_reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own cards" ON cards FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Users manage own state" ON user_state FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Users manage own reviews" ON card_reviews FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Users manage own sessions" ON sessions FOR ALL USING (auth.uid() = user_id);

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$ LANGUAGE plpgsql;

CREATE TRIGGER cards_updated_at BEFORE UPDATE ON cards FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER user_state_updated_at BEFORE UPDATE ON user_state FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Index for performance
CREATE INDEX idx_cards_user_review ON cards (user_id, next_review);
CREATE INDEX idx_cards_user_mastery ON cards (user_id, mastery);
CREATE INDEX idx_reviews_user ON card_reviews (user_id, created_at DESC);
